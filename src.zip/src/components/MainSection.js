import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './styles.css';
import courses from '../data/courses'; // Adjust the path as needed
import testimonials from '../data/testimonials'; // Adjust the path as needed

const MainSection = () => {
    const [featuredCourses, setFeaturedCourses] = useState([]);
    const [randomTestimonials, setRandomTestimonials] = useState([]);

    useEffect(() => {
        // Select 3 random courses
        const shuffledCourses = [...courses].sort(() => 0.5 - Math.random());
        setFeaturedCourses(shuffledCourses.slice(0, 3));

        // Select 2 random testimonials
        const shuffledTestimonials = [...testimonials].sort(() => 0.5 - Math.random());
        setRandomTestimonials(shuffledTestimonials.slice(0, 2));
    }, []);

    // Helper function to convert numeric rating to stars
    const getStarRating = (rating) => {
        const fullStars = Math.floor(rating);
        const halfStar = rating % 1 >= 0.5 ? '☆' : '';
        return '★'.repeat(fullStars) + halfStar + '☆'.repeat(5 - fullStars - (halfStar ? 1 : 0));
    };

    return (
        <div>
            <main>
                <section id="about">
                    <h2>About LMS</h2>
                    <p>The Learning Management System (LMS) helps students and instructors manage courses, quizzes, and track performance efficiently.</p>
                </section>
                <br></br>
                <section id="featured-courses">
                    <h2>Featured Courses</h2>
                    <ul>
                        {featuredCourses.map((course, index) => (
                            <li key={index}>
                                <h3>{course.name}</h3>
                                <p>{course.description}</p>
                            </li>
                        ))}
                    </ul>
                </section>
                <br></br>
                <section id="testimonials">
                    <h2>Testimonials</h2>
                    <ul>
                        {randomTestimonials.map((testimonial, index) => (
                            <li key={index}>
                                <p>"{testimonial.review}"</p>
                                <p>- {testimonial.studentName}</p>
                                <p>Rating: {getStarRating(testimonial.rating)}</p>
                            </li>
                        ))}
                    </ul>
                </section>
            </main>
        </div>
    );
};

export default MainSection;
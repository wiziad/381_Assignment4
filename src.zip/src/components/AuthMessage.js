import React from 'react';
import DisplayStatus from './DisplayStatus';

const AuthMessage = () => {
    return <DisplayStatus />;
};

export default AuthMessage;
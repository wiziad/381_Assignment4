const courses = [
  {
    id: 1,
    name: "Web Development",
    instructor: "Dr. John Smith",
    description: "Master HTML, CSS, and JavaScript.",
    duration: "8 weeks",
    image: "images/course1.jpg",
    creditHours: 3
  },
  {
    id: 2,
    name: "Data Structures",
    instructor: "Prof. Sarah Johnson",
    description: "Learn fundamental data structures and algorithms.",
    duration: "10 weeks",
    image: "images/course2.jpg",
    creditHours: 4
  },
  {
    id: 3,
    name: "Database Systems",
    instructor: "Dr. Michael Brown",
    description: "Understanding database design and SQL.",
    duration: "12 weeks",
    image: "images/course3.jpg",
    creditHours: 3
  },
  {
    id: 4,
    name: "Machine Learning",
    instructor: "Prof. Emily Davis",
    description: "Introduction to ML algorithms and applications.",
    duration: "14 weeks",
    image: "images/course4.jpg",
    creditHours: 4
  },
  {
    id: 5,
    name: "Software Engineering",
    instructor: "Dr. Robert Wilson",
    description: "Software development methodologies and practices.",
    duration: "10 weeks",
    image: "images/course5.jpg",
    creditHours: 3
  }
];

export default courses; 
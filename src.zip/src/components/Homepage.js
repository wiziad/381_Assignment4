import React, { useState, useEffect } from 'react';
import Header from './Header';
import Footer from './Footer';
import MainSection from './MainSection';
import './CoursesPage.css';

function Homepage () {
  return (
    <div>
        <Header />
        <MainSection />
        <Footer />
    </div>
  );
};

export default Homepage; 
import React from 'react';
import './EnrolledCourse.css';

const EnrolledCourse = ({ course, onDrop }) => {
  return (
    <div className="enrolled-course">
      <div className="enrolled-course-info">
        <h4>{course.name}</h4>
        <p>Credit Hours: {course.creditHours}</p>
      </div>
      <button 
        className="drop-button"
        onClick={() => onDrop(course)}
      >
        Drop Course
      </button>
    </div>
  );
};

export default EnrolledCourse; 
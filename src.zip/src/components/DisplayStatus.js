import React, { useContext } from 'react';
import './styles.css';
import { AuthContext } from './LoginForm';

const DisplayStatus = () => {
    const { authMessage } = useContext(AuthContext);
    return authMessage.text ? (
        <div className={`message-box ${authMessage.type}`}>{authMessage.text}</div>
    ) : null;
};

export default DisplayStatus;
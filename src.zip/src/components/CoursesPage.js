import React, { useState, useEffect } from 'react';
import CourseCatalog from './CourseCatalog';
import EnrollmentList from './EnrollmentList';
import Header from './Header';
import Footer from './Footer';
import courses from '../data/courses';
import './CoursesPage.css';

const CoursesPage = () => {
  const [enrolledCourses, setEnrolledCourses] = useState([]);

  useEffect(() => {
    const savedCourses = localStorage.getItem('enrolledCourses');
    if (savedCourses) {
      setEnrolledCourses(JSON.parse(savedCourses));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('enrolledCourses', JSON.stringify(enrolledCourses));
  }, [enrolledCourses]);

  const handleEnroll = (course) => {
    setEnrolledCourses(prevCourses => {
      if (prevCourses.some(c => c.id === course.id)) {
        return prevCourses;
      }
      return [...prevCourses, course];
    });
  };

  return (
    <div className="courses-page">
      <Header />
      <div className="courses-content">
        <CourseCatalog 
          courses={courses}
          onEnroll={handleEnroll}
        />
        <EnrollmentList />
      </div>
      <Footer />
    </div>
  );
};

export default CoursesPage; 
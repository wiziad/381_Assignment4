const testimonials = [
  {
    studentName: "Alice Johnson",
    courseName: "Web Development",
    review: "Excellent course structure!",
    rating: 5
  },
  {
    studentName: "Bob Wilson",
    courseName: "Data Structures",
    review: "Great instructor and challenging content.",
    rating: 4
  },
  {
    studentName: "Carol Smith",
    courseName: "Database Systems",
    review: "Very practical and hands-on learning.",
    rating: 5
  },
  {
    studentName: "David Brown",
    courseName: "Machine Learning",
    review: "Complex topics explained clearly.",
    rating: 4
  }
];

export default testimonials; 
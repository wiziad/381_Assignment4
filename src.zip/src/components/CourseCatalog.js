import React from 'react';
import CourseItem from './CourseItem';
import './CourseCatalog.css';

const CourseCatalog = ({ courses }) => {
  const handleEnroll = (course) => {
    const event = new CustomEvent('enrollCourse', { detail: course });
    window.dispatchEvent(event);
  };

  return (
    <div className="course-catalog">
      <h2>Available Courses</h2>
      <div className="courses-grid">
        {courses.map(course => (
          <CourseItem
            key={course.id}
            course={course}
            onEnroll={handleEnroll}
          />
        ))}
      </div>
    </div>
  );
};

export default CourseCatalog; 
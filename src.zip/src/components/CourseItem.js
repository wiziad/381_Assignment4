import React, { useState } from 'react';
import './CourseItem.css';
import courseImage from '../images/course1.jpg';

const CourseItem = ({ course, onEnroll }) => {
  const [showDescription, setShowDescription] = useState(false);

  return (
    <div 
      className="course-item"
      onMouseEnter={() => setShowDescription(true)}
      onMouseLeave={() => setShowDescription(false)}
    >
      <img src={courseImage} alt={course.name} className="course-image" />
      <div className="course-info">
        <h3>{course.name}</h3>
        <p>Instructor: {course.instructor}</p>
        {showDescription && (
          <div className="course-description">
            <p>{course.description}</p>
            <p>Duration: {course.duration}</p>
          </div>
        )}
        <button 
          className="enroll-button"
          onClick={() => onEnroll(course)}
        >
          Enroll Now
        </button>
      </div>
    </div>
  );
};

export default CourseItem; 
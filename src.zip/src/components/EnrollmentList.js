import React, { useState, useEffect } from 'react';
import EnrolledCourse from './EnrolledCourse';

const EnrollmentList = () => {
  const [enrolledCourses, setEnrolledCourses] = useState([]);

  useEffect(() => {
    const savedCourses = localStorage.getItem('enrolledCourses');
    if (savedCourses) {
      setEnrolledCourses(JSON.parse(savedCourses));
    }

    const handleEnrollCourse = (event) => {
      const course = event.detail;
      setEnrolledCourses(prevCourses => {
        if (prevCourses.some(c => c.id === course.id)) {
          return prevCourses;
        }
        return [...prevCourses, course];
      });
    };

    window.addEventListener('enrollCourse', handleEnrollCourse);
    return () => window.removeEventListener('enrollCourse', handleEnrollCourse);
  }, []);

  useEffect(() => {
    localStorage.setItem('enrolledCourses', JSON.stringify(enrolledCourses));
  }, [enrolledCourses]);

  const handleDropCourse = (course) => {
    setEnrolledCourses(prevCourses => {
      return prevCourses.filter(c => c.id !== course.id);
    });
  };

  const totalCreditHours = enrolledCourses.reduce((total, course) => total + course.creditHours, 0);

  return (
    <div className="enrollment-list">
      <h2>Enrolled Courses</h2>
      {enrolledCourses.length === 0 ? (
        <p>No courses enrolled yet.</p>
      ) : (
        <>
          {enrolledCourses.map(course => (
            <EnrolledCourse
              key={course.id}
              course={course}
              onDrop={handleDropCourse}
            />
          ))}
          <div className="total-credits">
            <h3>Total Credit Hours: {totalCreditHours}</h3>
          </div>
        </>
      )}
    </div>
  );
};

export default EnrollmentList; 
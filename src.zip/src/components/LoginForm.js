import React, { useState, createContext } from 'react';
import { useNavigate } from 'react-router-dom';
import AuthMessage from './AuthMessage';
import Header from './Header';
import Footer from './Footer';
import './styles.css';

export const AuthContext = createContext();

const LoginForm = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [authMessage, setAuthMessage] = useState({ type: '', text: '' });
    const navigate = useNavigate();

    const validateInputs = () => {
        if (!username || !password) {
            setAuthMessage({ type: 'error', text: 'Username and password cannot be empty.' });
            return false;
        }
        if (password.length < 8) {
            setAuthMessage({ type: 'error', text: 'Password must be at least 8 characters long.' });
            return false;
        }
        return true;
    };

    const handleLogin = async (e) => {
        e.preventDefault();
        if (!validateInputs()) return;

        setIsLoading(true);
        try {
            const response = await fetch('https://jsonplaceholder.typicode.com/users');
            const users = await response.json();
            const user = users.find((u) => u.username === username && u.email === password);

            if (user) {
                setAuthMessage({ type: 'success', text: 'Login successful! Redirecting...' });
                setTimeout(() => {
                    navigate('/courses');
                }, 2000);
            } else {
                setAuthMessage({ type: 'error', text: 'Invalid username or password!' });
            }
        } catch (error) {
            setAuthMessage({ type: 'error', text: 'Error fetching user data. Please try again.' });
            console.error('Error fetching users:', error);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <AuthContext.Provider value={{ authMessage, setAuthMessage }}>
            <div>
                <Header />
                <div className="login-page">
                    <main>
                        <form onSubmit={handleLogin} className="login-form">
                            <div className="login-container">
                                <label htmlFor="username">Username:</label>
                                <input
                                    type="text"
                                    id="username"
                                    value={username}
                                    onChange={(e) => setUsername(e.target.value)}
                                    required
                                />
                                <br />
                                <label htmlFor="password">Password:</label>
                                <input
                                    type="password"
                                    id="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    required
                                />
                                <br />
                                <AuthMessage />
                            </div>
                            <button type="submit" disabled={isLoading}>
                                {isLoading ? 'Logging in...' : 'Login'}
                            </button>
                        </form>
                        <a href="#">Forgot Password?</a>
                    </main>
                </div>
                <Footer />
            </div>
        </AuthContext.Provider>
    );
};

export default LoginForm;

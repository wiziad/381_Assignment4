import React from 'react';
import CourseCatalog from './CourseCatalog';
import EnrollmentList from './EnrollmentList';
import Header from './Header';
import Footer from './Footer';
import courses from '../data/courses';
import './CoursesPage.css';

const CoursesPage = () => {
  return (
    <div className="courses-page">
      <Header />
      <div className="content">
        <CourseCatalog courses={courses} />
        <EnrollmentList />
      </div>
      <Footer />
    </div>
  );
};

export default CoursesPage; 